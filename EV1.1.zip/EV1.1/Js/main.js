document.addEventListener("DOMContentLoaded", function () {
  // 🟢 Etiquetas flotantes
  const inputs = document.querySelectorAll(".contai-form input, .contai-form textarea");

  inputs.forEach(input => {
    const label = input.previousElementSibling;
    if (!label) return;

    input.addEventListener("keyup", () => {
      label.classList.toggle("active", input.value.trim() !== "");
      label.classList.toggle("highlight", input.value.trim() !== "");
    });

    input.addEventListener("blur", () => {
      label.classList.remove("highlight");
      if (input.value.trim() === "") label.classList.remove("active");
    });

    input.addEventListener("focus", () => {
      if (input.value.trim() !== "") label.classList.add("highlight");
    });
  });

  // 🟢 Cambio de pestañas
  const tabs = document.querySelectorAll(".contai-tabs li");
  const contents = document.querySelectorAll(".conte-tab > div");

  tabs.forEach((tab, index) => {
    tab.addEventListener("click", function (e) {
      e.preventDefault();
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      contents.forEach(c => c.classList.remove("active"));
      contents[index].classList.add("active");
    });
  });

  // Mostrar login por defecto
  if (contents.length > 0) {
    contents[0].classList.add("active");
    tabs[0].classList.add("active");
  }

  // 🟢 Validación personalizada del login
  const form = document.getElementById("form-login");
  const correo = document.getElementById("correo");
  const clave = document.getElementById("clave");

  form.addEventListener("submit", function (e) {
    const emailValue = correo.value.trim();
    const passwordValue = clave.value.trim();

    const dominiosPermitidos = ["@duoc.cl", "@profesor.duoc.cl", "@gmail.com"];
    const dominioValido = dominiosPermitidos.some(d => emailValue.endsWith(d));

    if (!dominioValido) {
      alert("El correo debe terminar en @duoc.cl, @profesor.duoc.cl o @gmail.com");
      e.preventDefault();
      return;
    }

    if (passwordValue.length < 4 || passwordValue.length > 10) {
      alert("La contraseña debe tener entre 4 y 10 caracteres.");
      e.preventDefault();
      return;
    }
  });

  // 🟢 Redirigir a login después de enviar el formulario de registro
const formRegistro = document.querySelector("#registrarse form");

formRegistro.addEventListener("submit", function (e) {
  e.preventDefault(); // Evita que se caiga la página

  // Aquí podrías validar o simular envío...

  // Cambiar pestaña activa
  const tabs = document.querySelectorAll(".contai-tabs li");
  const contents = document.querySelectorAll(".conte-tab > div");

  tabs.forEach(t => t.classList.remove("active"));
  tabs[0].classList.add("active"); // Activar "Iniciar Sesión"

  contents.forEach(c => c.classList.remove("active"));
  contents[0].classList.add("active"); // Mostrar contenido de login
  alert("Registro exitoso. Ahora puedes iniciar sesión.");
});

});
