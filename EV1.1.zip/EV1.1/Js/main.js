document.addEventListener("DOMContentLoaded", function () {
  const inputs = document.querySelectorAll(".contai-form input, .contai-form textarea");

  inputs.forEach(input => {
    const label = input.previousElementSibling;
    if (!label) return;

    input.addEventListener("keyup", () => {
      label.classList.toggle("active", input.value.trim() !== "");
      label.classList.toggle("highlight", input.value.trim() !== "");
    });

    input.addEventListener("blur", () => {
      label.classList.remove("highlight");
      if (input.value.trim() === "") label.classList.remove("active");
    });

    input.addEventListener("focus", () => {
      if (input.value.trim() !== "") label.classList.add("highlight");
    });
  });

  const tabs = document.querySelectorAll(".contai-tabs li");
  const contents = document.querySelectorAll(".conte-tab > div");

  tabs.forEach((tab, index) => {
    tab.addEventListener("click", function (e) {
      e.preventDefault();
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      contents.forEach(c => c.classList.remove("active"));
      contents[index].classList.add("active");
    });
  });

  if (contents.length > 0) {
    contents[0].classList.add("active");
    tabs[0].classList.add("active");
  }


  const form = document.getElementById("form-login");
  const correo = document.getElementById("correo");
  const clave = document.getElementById("clave");

  form.addEventListener("submit", function (e) {
    const emailValue = correo.value.trim();
    const passwordValue = clave.value.trim();

    const dominiosPermitidos = ["@duoc.cl", "@profesor.duoc.cl", "@gmail.com"];
    const dominioValido = dominiosPermitidos.some(d => emailValue.endsWith(d));

    if (!dominioValido) {
      alert("El correo debe terminar en @duoc.cl, @profesor.duoc.cl o @gmail.com");
      e.preventDefault();
      return;
    }

    if (passwordValue.length < 4 || passwordValue.length > 10) {
      alert("La contraseña debe tener entre 4 y 10 caracteres.");
      e.preventDefault();
      return;
    }
  });

 
  const formRegistro = document.querySelector("#registrarse form");

  formRegistro.addEventListener("submit", function (e) {
    e.preventDefault();

    const tabs = document.querySelectorAll(".contai-tabs li");
    const contents = document.querySelectorAll(".conte-tab > div");

    tabs.forEach(t => t.classList.remove("active"));
    tabs[0].classList.add("active"); 

    contents.forEach(c => c.classList.remove("active"));
    contents[0].classList.add("active");
    alert("Registro exitoso. Ahora puedes iniciar sesión.");
  });

});
