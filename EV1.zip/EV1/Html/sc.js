const comunasPorRegion = {
  aricayparinacota: ["Arica", "Camarones", "Putre", "General Lagos"],
  tarapacá: ["Iquique", "Alto Hospicio", "Pozo Almonte", "Camiña", "Colchane", "Huara", "Pica"],
  antofagasta: ["Antofagasta", "Mejillones", "Sierra Gorda", "Taltal", "Calama", "Ollagüe", "San Pedro de Atacama", "Tocopilla", "Maria Elena"],
  atacama: ["Copiapó", "Caldera", "Tierra Amarrilla", "Chañaral", "Diego de Almagro", "Vallenar", "Alto del Carmen", "Freirina", "Huasco"],
  coquimbo: ["La Serena", "Coquimbo", "Andacollo", "La Higuera", "Paihuano", "Viucuña", "Lllapel", "Canela", "Los Vilos", "Salamanca", "Ovalle", "Combarbalá", "Monte Patria", "Punitaqui", "Rio Hurtado"],
  valparaíso: ["Valparaíso", "Casablanca", "Concón", "Juan Fernández", "Puchuncaví", "Quintero", "Viña del Mar", "Isla de Pascua", "Los Andes", "Calle Larga", "Rinconada", "San Esteban", "La Ligua", "Cabildo", "Papudo", "Petorca", "Zapallar", "Quillota", "La Calera", "Hijuelas", "La Cruz", 
  "Nogales", "San Antonio", "Algarrobo", "Cartagena", "El Quisco", "El Tabo", "Santo Domingo", "San Felipe", "Catemu", "Llay-Llay", "Panquehue", "Putaendo", "Santa Maria", "Quilpué", "Limache", "Olmué", "Villa Alemana"],
  tarapacá: [""],
  tarapacá: [""],
  tarapacá: [""],
  tarapacá: [""],
  tarapacá: [""],
  tarapacá: [""],
  tarapacá: [""],
  metropolitana: ["Santiago", "Puente Alto", "Maipú"],
  araucania: ["Temuco", "Padre Las Casas", "Angol"],
  nuble: ["Chillán", "San Carlos", "Coihueco"]
};

const regionSelect = document.getElementById("region");
const comunaSelect = document.getElementById("comuna");

regionSelect.addEventListener("change", function () {
  const region = this.value;

  comunaSelect.innerHTML = '<option value="">-- Seleccione la comuna --</option>';

  if (comunasPorRegion[region]) {
    comunasPorRegion[region].forEach(comuna => {
      const option = document.createElement("option");
      option.value = comuna.toLowerCase().replace(/\s/g, "-");
      option.textContent = comuna;
      comunaSelect.appendChild(option);
    });
  }
});
